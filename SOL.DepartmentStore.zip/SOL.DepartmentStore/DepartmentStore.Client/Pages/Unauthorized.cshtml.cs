using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace DepartmentStore.Client.Pages
{
    public class UnauthorizedModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
